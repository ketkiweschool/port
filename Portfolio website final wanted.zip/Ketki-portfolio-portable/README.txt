KETKI PORTFOLIO — PORTABLE COPY

Unzip this folder, then open index.html in a modern browser. Portfolio photos are embedded in the HTML; keep the included PDF and certificate files beside/in their folders for the resume and certificate links.
